<input type="hidden" name="type" value="vendor">
<?php 
$item_type = 'vendor';
include dirname( dirname( __FILE__ ) ) . '/user-form-rows.php'; 
?>