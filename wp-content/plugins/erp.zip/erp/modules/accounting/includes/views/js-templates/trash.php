<label><?php _e( 'Status', 'erp' ); ?><span class="required">*</span></label>
<select name="status" required="required">
	<option value="draft"><?php _e( 'Draft', 'erp' ); ?></option>
	<option value="pending"><?php _e( 'Awating for approval', 'erp' ); ?></option>
</select>
