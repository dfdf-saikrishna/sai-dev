<input type="hidden" name="type" value="customer">
<?php 
$item_type = 'customer';
include dirname( dirname( __FILE__ ) ) . '/user-form-rows.php'; 
?>
