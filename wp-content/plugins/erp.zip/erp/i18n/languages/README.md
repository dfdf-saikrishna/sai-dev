# WARNING! DO NOT PUT CUSTOM TRANSLATIONS HERE!

WP ERP will delete all custom translations placed in this directory.

## Translating
Put your custom WP ERP translations in your WordPress language directory, located at: WP_LANG_DIR . "/wp-erp/{$textdomain}-{$locale}.mo";